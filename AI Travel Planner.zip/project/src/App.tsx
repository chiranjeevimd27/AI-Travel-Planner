import React, { useState, useMemo } from 'react';
import { Plane, Calendar, DollarSign, MapPin, Heart, Clock, Utensils, Hotel, Footprints } from 'lucide-react';

interface TravelPreferences {
  budget: string;
  duration: string;
  startLocation: string;
  destination: string;
  purpose: string;
  dietary: string;
  interests: string[];
  mobility: string;
  accommodation: string;
}

interface DayPlan {
  morning: string;
  afternoon: string;
  evening: string;
}

function App() {
  const [step, setStep] = useState(1);
  const [preferences, setPreferences] = useState<TravelPreferences>({
    budget: '',
    duration: '',
    startLocation: '',
    destination: '',
    purpose: '',
    dietary: '',
    interests: [],
    mobility: '',
    accommodation: ''
  });

  const handleInputChange = (field: keyof TravelPreferences, value: string | string[]) => {
    setPreferences(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const generateItinerary = (destination: string): DayPlan[] => {
    const parisItinerary: DayPlan[] = [
      {
        morning: 'Arrival and Hotel Check-in',
        afternoon: 'City Orientation Walk around Le Marais',
        evening: 'Welcome Dinner at a Traditional French Bistro'
      },
      {
        morning: 'Visit the Eiffel Tower (book tickets in advance)',
        afternoon: 'Seine River Cruise',
        evening: 'Dinner at Montmartre with City Views'
      },
      {
        morning: 'Louvre Museum Tour',
        afternoon: 'Shopping at Champs-Élysées',
        evening: 'Arc de Triomphe Visit & Dinner'
      },
      {
        morning: 'Visit Notre-Dame Cathedral Reconstruction Site',
        afternoon: 'Luxembourg Gardens & Latin Quarter',
        evening: 'Food Tour in Saint-Germain'
      },
      {
        morning: 'Palace of Versailles Day Trip',
        afternoon: 'Explore Versailles Gardens',
        evening: 'Return to Paris - Dinner at Le Marais'
      },
      {
        morning: 'Musée d\'Orsay Visit',
        afternoon: 'Saint-Germain-des-Prés Walking Tour',
        evening: 'Seine-side Dinner Cruise'
      },
      {
        morning: 'Local Market Visit & Cooking Class',
        afternoon: 'Sacré-Cœur & Montmartre Tour',
        evening: 'Farewell Dinner at Michelin-starred Restaurant'
      }
    ];

    const defaultDay: DayPlan = {
      morning: 'Free time for personal exploration',
      afternoon: 'Optional guided tours or shopping',
      evening: 'Dinner at recommended local restaurant'
    };

    const duration = parseInt(preferences.duration) || 7;
    const itinerary: DayPlan[] = [];

    for (let i = 0; i < duration; i++) {
      itinerary.push(parisItinerary[i] || defaultDay);
    }

    return itinerary;
  };

  const itinerary = useMemo(() => generateItinerary(preferences.destination), [preferences.destination, preferences.duration]);

  const renderStep1 = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-6">Basic Travel Information</h2>
      
      <div className="space-y-4">
        <div className="flex items-center space-x-4">
          <DollarSign className="w-6 h-6 text-emerald-600" />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Budget Range</label>
            <select 
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
              value={preferences.budget}
              onChange={(e) => handleInputChange('budget', e.target.value)}
            >
              <option value="">Select budget range</option>
              <option value="budget">Budget ($0-$1000)</option>
              <option value="moderate">Moderate ($1000-$3000)</option>
              <option value="luxury">Luxury ($3000+)</option>
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <Calendar className="w-6 h-6 text-emerald-600" />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Trip Duration (days)</label>
            <input
              type="number"
              min="1"
              max="30"
              placeholder="e.g., 7"
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
              value={preferences.duration}
              onChange={(e) => handleInputChange('duration', e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <MapPin className="w-6 h-6 text-emerald-600" />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Starting Location</label>
            <input
              type="text"
              placeholder="e.g., New York"
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
              value={preferences.startLocation}
              onChange={(e) => handleInputChange('startLocation', e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <Plane className="w-6 h-6 text-emerald-600" />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Destination</label>
            <input
              type="text"
              placeholder="e.g., Paris"
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
              value={preferences.destination}
              onChange={(e) => handleInputChange('destination', e.target.value)}
            />
          </div>
        </div>
      </div>

      <button
        onClick={() => setStep(2)}
        className="w-full bg-emerald-600 text-white py-3 rounded-lg hover:bg-emerald-700 transition-colors"
      >
        Next: Preferences
      </button>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-6">Travel Preferences</h2>
      
      <div className="space-y-4">
        <div className="flex items-center space-x-4">
          <Heart className="w-6 h-6 text-emerald-600" />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Purpose of Travel</label>
            <select
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
              value={preferences.purpose}
              onChange={(e) => handleInputChange('purpose', e.target.value)}
            >
              <option value="">Select purpose</option>
              <option value="leisure">Leisure</option>
              <option value="business">Business</option>
              <option value="adventure">Adventure</option>
              <option value="cultural">Cultural Experience</option>
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <Utensils className="w-6 h-6 text-emerald-600" />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Dietary Preferences</label>
            <select
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
              value={preferences.dietary}
              onChange={(e) => handleInputChange('dietary', e.target.value)}
            >
              <option value="">Select dietary preference</option>
              <option value="none">No Restrictions</option>
              <option value="vegetarian">Vegetarian</option>
              <option value="vegan">Vegan</option>
              <option value="halal">Halal</option>
              <option value="kosher">Kosher</option>
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <Footprints className="w-6 h-6 text-emerald-600" />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Mobility/Walking Tolerance</label>
            <select
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
              value={preferences.mobility}
              onChange={(e) => handleInputChange('mobility', e.target.value)}
            >
              <option value="">Select mobility level</option>
              <option value="high">High - Can walk for hours</option>
              <option value="moderate">Moderate - Regular breaks needed</option>
              <option value="low">Low - Minimal walking preferred</option>
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <Hotel className="w-6 h-6 text-emerald-600" />
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">Accommodation Preference</label>
            <select
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-emerald-500"
              value={preferences.accommodation}
              onChange={(e) => handleInputChange('accommodation', e.target.value)}
            >
              <option value="">Select accommodation type</option>
              <option value="luxury">Luxury Hotels</option>
              <option value="midrange">Mid-range Hotels</option>
              <option value="budget">Budget Hotels/Hostels</option>
              <option value="apartment">Vacation Rentals/Apartments</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex space-x-4">
        <button
          onClick={() => setStep(1)}
          className="w-1/2 bg-gray-200 text-gray-800 py-3 rounded-lg hover:bg-gray-300 transition-colors"
        >
          Back
        </button>
        <button
          onClick={() => setStep(3)}
          className="w-1/2 bg-emerald-600 text-white py-3 rounded-lg hover:bg-emerald-700 transition-colors"
        >
          Generate Itinerary
        </button>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold mb-6">Your Travel Itinerary</h2>
      
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold">{preferences.destination}</h3>
            <p className="text-gray-600">{preferences.duration} days</p>
          </div>
          <Clock className="w-6 h-6 text-emerald-600" />
        </div>

        <div className="space-y-4">
          {itinerary.map((day, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg">
              <h4 className="font-semibold mb-2">Day {index + 1}</h4>
              <ul className="list-disc list-inside text-gray-700 space-y-2">
                <li>Morning: {day.morning}</li>
                <li>Afternoon: {day.afternoon}</li>
                <li>Evening: {day.evening}</li>
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-6 space-y-4">
          <button
            onClick={() => setStep(1)}
            className="w-full bg-emerald-600 text-white py-3 rounded-lg hover:bg-emerald-700 transition-colors"
          >
            Start New Plan
          </button>
          <button
            onClick={() => window.print()}
            className="w-full bg-gray-200 text-gray-800 py-3 rounded-lg hover:bg-gray-300 transition-colors"
          >
            Print Itinerary
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-2xl mx-auto p-6">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-emerald-600">AI Travel Planner</h1>
          <p className="text-gray-600 mt-2">Create your personalized travel itinerary</p>
        </header>

        {step === 1 && renderStep1()}
        {step === 2 && renderStep2()}
        {step === 3 && renderStep3()}
      </div>
    </div>
  );
}

export default App;